//! Redstone dust — `RedStoneWireBlock` + `DefaultRedstoneWireEvaluator`,
//! transcribed.
//!
//! Vanilla relaxes dust **one wire at a time**: a notified wire recomputes its
//! own target strength from the world as it stands, writes it silently
//! (flag 2), and then runs `updateNeighborsAt` for itself and its six
//! neighbours — seven entries whose order is the iteration order of a
//! `HashSet<BlockPos>`, which this module reproduces bucket-for-bucket
//! (`java_hash_order`). The recursion through the collector is what produces
//! the ordered transients ("locational dust") that real builds latch onto —
//! the five community door fixtures refused the previous ideal fixed-point
//! model and forced this transcription.
//!
//! - Target: `blockSignal`, or if that is under 15, `max(blockSignal,
//!   incomingWireSignal)`; incoming scans the four horizontals plus the
//!   diagonal rules (up over a conductor when uncovered, down past a
//!   non-conductor — the glass diode), minus the 1-per-block falloff.
//! - Connection shapes *are* recomputed, from `updateShape` — a wire re-faces
//!   itself whenever a neighbour changes shape, which is how dust follows a
//!   door that moves the blocks around it.

use crate::behaviour::{BlockBehaviour, TickCtx};
use crate::pos::{Dir, Pos};
use crate::state::StateId;
use crate::world::World;

/// What the wire needs to know about everything that is not wire.
pub trait WireWorld: Send + Sync {
    /// Optional concrete-rule experiment. Implementations with observable or
    /// custom query behavior keep the default exact evaluator.
    #[cfg(feature = "experiment-wire-plan")]
    fn planned_target(
        &self,
        _world: &World,
        _outputs: &crate::behaviour::ComparatorOutputs,
        _pos: Pos,
    ) -> Option<u8> { None }

    /// Where this world's `(0, 0, 0)` sits in the game's coordinates.
    ///
    /// Only `updatePowerStrength`'s `HashSet<BlockPos>` needs it, and only
    /// because that set's iteration order is a function of absolute position.
    /// Zero for a fixture placed at the origin; the recorded origin for a build
    /// captured where it stands.
    fn hash_origin(&self) -> Pos {
        Pos::new(0, 0, 0)
    }

    /// The strongest non-wire signal into the wire at `pos` (vanilla's
    /// `getBlockSignal` with `shouldSignal` off, so wires never count).
    fn block_signal(&self, ctx: &TickCtx<'_>, pos: Pos) -> u8;
    /// Whether the block at `pos` conducts (`isRedstoneConductor`).
    fn conductor(&self, world: &World, pos: Pos) -> bool;
    /// The power level of the wire at `pos`, if it is wire.
    fn wire_power(&self, world: &World, pos: Pos) -> Option<u8>;
    /// The same wire state with a different power level.
    fn wire_with_power(&self, world: &World, pos: Pos, power: u8) -> Option<StateId>;
    /// The wire at `pos` as `(power, [north, south, west, east])`, if it is wire.
    fn wire_shape(&self, world: &World, pos: Pos) -> Option<(u8, [WireSide; 4])>;
    /// The wire state with exactly this power and these connections.
    fn wire_with_shape(&self, power: u8, sides: [WireSide; 4]) -> Option<StateId>;
    /// `shouldConnectTo`: whether dust turns to face the block at `pos`.
    /// `from` is the direction from the wire toward it; `None` asks the
    /// direction-agnostic question the diagonal checks use.
    fn should_connect_to(&self, world: &World, pos: Pos, from: Option<Dir>) -> bool;
    /// `canSurviveOn`: whether dust could sit on the block at `pos`, which is
    /// also what decides whether it can climb it.
    fn sturdy_up(&self, world: &World, pos: Pos) -> bool;
    /// `isCollisionShapeFullBlock`: a wire climbing a *full* block renders as
    /// `up`; climbing anything shallower stays `side`.
    fn full_block(&self, world: &World, pos: Pos) -> bool;
}

/// A dust connection: `RedstoneSide`.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub enum WireSide {
    /// `none` — no connection on this face.
    None,
    /// `side` — connected horizontally.
    Side,
    /// `up` — connected, and climbing the block on this face.
    Up,
}

impl WireSide {
    /// `RedstoneSide.isConnected`: `up` and `side` both carry signal.
    pub fn connected(self) -> bool {
        self != WireSide::None
    }
}

/// The four horizontals in the order the connection arrays use.
pub const WIRE_SIDES: [Dir; 4] = [Dir::North, Dir::South, Dir::West, Dir::East];

/// The index into a connection array for a horizontal direction.
fn side_index(dir: Dir) -> Option<usize> {
    WIRE_SIDES.iter().position(|d| *d == dir)
}

/// `RedStoneWireBlock.getConnectingSide`: what the wire at `pos` does on the
/// face toward `dir`.
///
/// `can_connect_up` is the caller's cached "nothing solid overhead", because a
/// covered wire cannot climb anything.
pub fn connecting_side(
    rules: &dyn WireWorld,
    world: &World,
    pos: Pos,
    dir: Dir,
    can_connect_up: bool,
) -> WireSide {
    let side = pos.offset(dir);
    let climbs = can_connect_up
        && rules.sturdy_up(world, side)
        && rules.should_connect_to(world, side.offset(Dir::Up), None);
    if climbs {
        let out = if rules.full_block(world, side) {
            WireSide::Up
        } else {
            WireSide::Side
        };
        trace_side(rules, world, pos, dir, out, can_connect_up, true);
        return out;
    }
    // Otherwise the wire faces the block only if that block takes a signal, or
    // if there is dust below it to step down onto — and a conductor blocks the
    // step down, which is what makes glass a diode.
    let out = if !rules.should_connect_to(world, side, Some(dir))
        && (rules.conductor(world, side)
            || !rules.should_connect_to(world, side.offset(Dir::Down), None))
    {
        WireSide::None
    } else {
        WireSide::Side
    };
    trace_side(rules, world, pos, dir, out, can_connect_up, false);
    out
}

/// `MC_TICK_TRACE_SIDE=x,y,z[;...]` — why a wire faced the way it did.
///
/// Connection shape is decided by a five-term expression over the neighbour,
/// the block above it and the block below it, and a wrong answer looks
/// identical to a missing update from the outside. Printing the terms is the
/// difference between reading the divergence and guessing at it.
fn trace_side(
    rules: &dyn WireWorld,
    world: &World,
    pos: Pos,
    dir: Dir,
    out: WireSide,
    can_connect_up: bool,
    climbed: bool,
) {
    let Some(filter) = crate::diagnostics::var_os("MC_TICK_TRACE_SIDE") else {
        return;
    };
    let wanted = filter.to_string_lossy().split(';').any(|t| {
        let c: Vec<i32> = t.split(',').filter_map(|v| v.trim().parse().ok()).collect();
        c.len() == 3 && c[0] == pos.x && c[1] == pos.y && c[2] == pos.z
    });
    if !wanted {
        return;
    }
    let side = pos.offset(dir);
    eprintln!(
        "[side] {:?} {dir:?} -> {out:?} via {}  canUp={can_connect_up} sturdyUp={} aboveConnects={} \
full={} sideConnects={} cond={} belowConnects={}",
        (pos.x, pos.y, pos.z),
        if climbed { "climb" } else { "flat" },
        rules.sturdy_up(world, side),
        rules.should_connect_to(world, side.offset(Dir::Up), None),
        rules.full_block(world, side),
        rules.should_connect_to(world, side, Some(dir)),
        rules.conductor(world, side),
        rules.should_connect_to(world, side.offset(Dir::Down), None),
    );
}

/// `getConnectionState`: recompute every unconnected face, then apply the
/// symmetry rule — a wire connected on one axis only spreads *across* the
/// other, so a single-neighbour cell renders as a line rather than a stub.
///
/// A wire that was a dot and stays a dot keeps its dot shape; that is the one
/// case vanilla leaves alone.
pub fn connection_state(
    rules: &dyn WireWorld,
    world: &World,
    pos: Pos,
    current: [WireSide; 4],
) -> [WireSide; 4] {
    let was_dot = current.iter().all(|s| !s.connected());
    let can_connect_up = !rules.conductor(world, pos.offset(Dir::Up));
    let mut sides = [WireSide::None; 4];
    for (index, dir) in WIRE_SIDES.iter().enumerate() {
        sides[index] = connecting_side(rules, world, pos, *dir, can_connect_up);
    }
    if was_dot && sides.iter().all(|s| !s.connected()) {
        return sides;
    }
    let [north, south, west, east] = sides;
    let no_north_south = !north.connected() && !south.connected();
    let no_west_east = !west.connected() && !east.connected();
    if !west.connected() && no_north_south {
        sides[2] = WireSide::Side;
    }
    if !east.connected() && no_north_south {
        sides[3] = WireSide::Side;
    }
    if !north.connected() && no_west_east {
        sides[0] = WireSide::Side;
    }
    if !south.connected() && no_west_east {
        sides[1] = WireSide::Side;
    }
    sides
}

/// Demand-driven connectedness for the concrete vanilla rules. The public
/// `WireWorld` trait does not promise pure queries, so its generic full-shape
/// operation deliberately retains its original calls and order.
#[cfg(feature = "experiment-directional")]
pub(crate) fn connects_toward(
    rules: &crate::vanilla::VanillaRules,
    world: &World,
    pos: Pos,
    current: [WireSide; 4],
    toward: Dir,
) -> bool {
    let can_connect_up = !rules.conductor(world, pos.offset(Dir::Up));
    connected_toward_by(current, toward, |dir| {
        connecting_side(rules, world, pos, dir, can_connect_up)
    })
}

#[cfg(feature = "experiment-directional")]
fn connected_toward_by(
    current: [WireSide; 4],
    toward: Dir,
    mut raw_side: impl FnMut(Dir) -> WireSide,
) -> bool {
    let perpendicular = match toward {
        Dir::North | Dir::South => [Dir::West, Dir::East],
        Dir::West | Dir::East => [Dir::North, Dir::South],
        _ => return false,
    };
    if raw_side(toward).connected() {
        return true;
    }
    if perpendicular.into_iter().any(|dir| raw_side(dir).connected()) {
        return false;
    }
    // With no perpendicular connection, symmetry fills this side unless the
    // stored state was a dot and every raw side remains disconnected.
    current.iter().any(|side| side.connected()) || raw_side(toward.opposite()).connected()
}

/// `getIncomingWireSignal`: the strongest neighbouring wire, minus one.
pub(crate) fn incoming(rules: &dyn WireWorld, world: &World, pos: Pos) -> u8 {
    let mut best = 0u8;
    let covered = rules.conductor(world, pos.offset(Dir::Up));
    for dir in [Dir::North, Dir::South, Dir::West, Dir::East] {
        let side = pos.offset(dir);
        if let Some(power) = rules.wire_power(world, side) {
            best = best.max(power);
        }
        if rules.conductor(world, side) {
            if !covered {
                if let Some(power) = rules.wire_power(world, side.offset(Dir::Up)) {
                    best = best.max(power);
                }
            }
        } else if let Some(power) = rules.wire_power(world, side.offset(Dir::Down)) {
            best = best.max(power);
        }
    }
    best.saturating_sub(1)
}

/// The iteration order of a fresh Java `HashSet<BlockPos>` holding `pos` and
/// its six neighbours, inserted as vanilla inserts them (`pos`, then
/// `Direction.values()`): 16 buckets, index `(h ^ (h >>> 16)) & 15` over
/// `Vec3i.hashCode()` = `(y + z·31)·31 + x`, chains appended, iterated bucket
/// by bucket.
pub fn java_hash_order(pos: Pos, origin: Pos) -> Vec<Pos> {
    java_hash_order_array(pos, origin).to_vec()
}

fn java_hash_order_array(pos: Pos, origin: Pos) -> [Pos; 7] {
    let mut entries = [pos; 7];
    for (i, dir) in crate::pos::JAVA_DIRECTIONS.into_iter().enumerate() {
        entries[i + 1] = pos.offset(dir);
    }
    // Stable sorting retains insertion order within a Java bucket collision.
    // Seven entries cannot resize the sixteen-bucket table.
    entries.sort_by_key(|p| {
        let x = p.x.wrapping_add(origin.x);
        let y = p.y.wrapping_add(origin.y);
        let z = p.z.wrapping_add(origin.z);
        let hash = y.wrapping_add(z.wrapping_mul(31)).wrapping_mul(31).wrapping_add(x);
        (hash ^ (((hash as u32) >> 16) as i32)) & 15
    });
    entries
}

/// `DefaultRedstoneWireEvaluator.updatePowerStrength` for the wire at `pos`.
pub fn update_power_strength(rules: &dyn WireWorld, ctx: &mut TickCtx<'_>, pos: Pos, current: u8) {
    #[cfg(feature = "experiment-wire-plan")]
    let planned = rules.planned_target(ctx.world, ctx.comparator_out, pos);
    #[cfg(not(feature = "experiment-wire-plan"))]
    let planned: Option<u8> = None;
    let target = planned.unwrap_or_else(|| {
    let block = rules.block_signal(ctx, pos);
    if block == 15 {
        15
    } else {
        block.max(incoming(rules, ctx.world, pos))
    }
    });
    if target == current {
        return;
    }
    if let Some(state) = rules.wire_with_power(ctx.world, pos, target) {
        // setBlock flag 2: no neighbour updates, but the shape pass still
        // runs — which is how an observer watching dust sees the change.
        ctx.set_shape_only(pos, state);
    }
    // Seven updateNeighborsAt entries, in the HashSet's iteration order.
    for p in java_hash_order_array(pos, rules.hash_origin()) {
        ctx.update_neighbors_at(p);
    }
}

/// `RedStoneWireBlock.updateNeighborsOfNeighboringWires`: every horizontal
/// neighbour that is itself dust gets an update pass, and so does the dust one
/// step up or down from that neighbour — up when the neighbour conducts, down
/// when it does not, which is exactly how dust follows a staircase.
pub fn update_neighbours_of_neighbouring_wires(
    rules: &dyn WireWorld,
    ctx: &mut TickCtx<'_>,
    pos: Pos,
) {
    // `Direction.Plane.HORIZONTAL` order — clockwise, not `values()` order.
    const HORIZONTAL: [Dir; 4] = [Dir::North, Dir::East, Dir::South, Dir::West];
    for dir in HORIZONTAL {
        check_corner_change_at(rules, ctx, pos.offset(dir));
    }
    for dir in HORIZONTAL {
        let side = pos.offset(dir);
        let step = if rules.conductor(ctx.world, side) {
            Dir::Up
        } else {
            Dir::Down
        };
        check_corner_change_at(rules, ctx, side.offset(step));
    }
}

/// `checkCornerChangeAt`: an update pass, but only if that position is dust.
fn check_corner_change_at(rules: &dyn WireWorld, ctx: &mut TickCtx<'_>, pos: Pos) {
    if rules.wire_power(ctx.world, pos).is_some() {
        ctx.update_neighbors_at(pos);
    }
}

/// Redstone dust. One instance per wire state; the connection shape comes from
/// the structure and is not recomputed (documented limitation — a piston
/// rearranging blocks beside dust would change shapes in vanilla).
pub struct Wire<R: WireWorld + Clone> {
    /// This state's power level.
    pub power_level: u8,
    /// The world rules.
    pub rules: R,
}

impl<R: WireWorld + Clone + 'static> BlockBehaviour for Wire<R> {
    /// `RedStoneWireBlock.onRemove`: with the wire gone, update the
    /// neighbours of each of its six neighbours — the two-step sweep that
    /// tells a torch mounted on the wire's target block that its support
    /// went dark.
    fn on_removed(&self, ctx: &mut TickCtx<'_>, pos: Pos) {
        for dir in crate::pos::ALL_DIRS {
            ctx.update_neighbors_at(pos.offset(dir));
        }
    }

    /// `RedStoneWireBlock.updateIndirectNeighbourShapes`: for every horizontal
    /// side this wire is connected on whose neighbour is *not itself wire*,
    /// shape-update the wire directly below that neighbour and the wire
    /// directly above it.
    ///
    /// That is the diagonal step of a staircase. A wire climbing a block is
    /// connected to the block, not to the wire on top of it, so nothing in the
    /// six-neighbour pass ever reaches its partner — this is the only thing
    /// that does. The 6x6 door's outer edges are built from exactly this shape
    /// and stayed dead without it.
    fn indirect_shape_targets(&self, world: &World, pos: Pos) -> Vec<(Pos, Dir)> {
        // `Direction.Plane.HORIZONTAL` is declared clockwise — NORTH, EAST,
        // SOUTH, WEST — not in `Direction.values()` order, which puts WEST
        // before EAST. A loop written against the wrong one emits the same set
        // of updates in a different sequence, and redstone is order-sensitive.
        const HORIZONTAL: [Dir; 4] = [Dir::North, Dir::East, Dir::South, Dir::West];
        let Some((_, sides)) = self.rules.wire_shape(world, pos) else {
            return Vec::new();
        };
        let mut out = Vec::new();
        for dir in HORIZONTAL {
            let Some(index) = side_index(dir) else {
                continue;
            };
            if sides[index] == WireSide::None {
                continue;
            }
            let side = pos.offset(dir);
            if self.rules.wire_power(world, side).is_some() {
                continue;
            }
            for step in [Dir::Down, Dir::Up] {
                let partner = side.offset(step);
                if self.rules.wire_power(world, partner).is_some() {
                    out.push((partner, dir.opposite()));
                }
            }
        }
        out
    }

    fn on_neighbor_changed(&self, ctx: &mut TickCtx<'_>, pos: Pos, _from: Dir) {
        update_power_strength(&self.rules, ctx, pos, self.power_level);
    }

    /// `RedStoneWireBlock.onPlace` runs `updatePowerStrength` too, so dust
    /// recomputes itself the moment it is written into the world.
    ///
    /// That is what corrects the authored power level of a schematic: a build
    /// saved with dust at 1 is placed, each wire re-evaluates, and the ones
    /// with nothing feeding them drop to 0 — even under `knownShape`, where no
    /// update passes run at all. Without this the engine kept the file's
    /// values and started three cells hot.
    /// The rest of `onPlace` matters just as much, and is *unconditional*:
    /// whatever the recomputed power, dust always pokes the neighbours of the
    /// blocks above and below it, plus any neighbouring wires. That reaches two
    /// blocks out — a wire sitting on a barrel notifies the comparator on the
    /// barrel's far side — and it is the only thing that wakes diodes during a
    /// `knownShape` placement, where no update pass runs.
    fn on_placed(&self, ctx: &mut TickCtx<'_>, pos: Pos) {
        update_power_strength(&self.rules, ctx, pos, self.power_level);
        for dir in [Dir::Down, Dir::Up] {
            ctx.update_neighbors_at(pos.offset(dir));
        }
        update_neighbours_of_neighbouring_wires(&self.rules, ctx, pos);
    }

    /// `RedStoneWireBlock.updateShape`.
    ///
    /// From above, the whole connection state is recomputed. From a horizontal
    /// neighbour, vanilla takes a shortcut: if that face's *connectedness* is
    /// unchanged and the wire is not a cross, only that face is rewritten —
    /// which preserves an `up` that a full recompute would flatten. Anything
    /// else recomputes from scratch, keeping only the power level.
    ///
    /// From below vanilla asks whether the dust can still survive
    /// (`canSurviveOn`) and pops it when it cannot. The one measured pop is
    /// dust on a **test block** under a *plain* structure placement
    /// (`cuc_placed.txt`, the oracle's dump) — but the gametest framework
    /// places with `knownShape`, no update passes run, and lithium's
    /// machines bank on that dust surviving: five of them hang their start
    /// wiring on it. The engine models the framework's placement, so no pop
    /// here.
    fn on_shape_update(&self, ctx: &mut TickCtx<'_>, pos: Pos, from: Dir) {
        if from == Dir::Down {
            return;
        }
        let Some((power, current)) = self.rules.wire_shape(ctx.world, pos) else {
            return;
        };
        let sides = if from == Dir::Up {
            connection_state(&self.rules, ctx.world, pos, current)
        } else {
            let Some(index) = side_index(from) else {
                return;
            };
            let is_cross = current.iter().all(|s| s.connected());
            let can_connect_up = !self.rules.conductor(ctx.world, pos.offset(Dir::Up));
            let side = connecting_side(&self.rules, ctx.world, pos, from, can_connect_up);
            if side.connected() == current[index].connected() && !is_cross {
                let mut sides = current;
                sides[index] = side;
                sides
            } else {
                connection_state(&self.rules, ctx.world, pos, current)
            }
        };
        if sides == current {
            return;
        }
        let Some(state) = self.rules.wire_with_shape(power, sides) else {
            return;
        };
        // A shape write, so it carries on through the shape pass without
        // notifying neighbours — the wire re-faces itself, and the dust beyond
        // it re-faces in turn.
        ctx.set_shape_only(pos, state);
    }

    fn name(&self) -> &'static str {
        "redstone_wire"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_hash_order_matches_javas_buckets() {
        // Hand-checked against Java: HashSet of (0,0,0) and neighbours.
        let order = java_hash_order(Pos::new(0, 0, 0), Pos::new(0, 0, 0));
        assert_eq!(order.len(), 7);
        // Every position appears exactly once.
        let mut seen = std::collections::HashSet::new();
        for p in &order {
            assert!(seen.insert(*p));
        }
    }
}

#[cfg(all(test, feature = "experiment-directional"))]
mod directional_tests {
    use super::*;
    use crate::pos::Bounds;

    struct RawSides([WireSide; 4]);

    impl RawSides {
        fn at(&self, pos: Pos) -> WireSide {
            WIRE_SIDES.into_iter().position(|dir| {
                let (x, _, z) = dir.delta();
                pos.x == x && pos.z == z
            }).map_or(WireSide::None, |index| self.0[index])
        }
    }

    // Materialize every possible raw result through the original public shape
    // calculation, so the oracle includes its dot and axis-symmetry behavior.
    impl WireWorld for RawSides {
        fn block_signal(&self, _: &TickCtx<'_>, _: Pos) -> u8 { 0 }
        fn conductor(&self, _: &World, pos: Pos) -> bool {
            pos.y == 0 && self.at(pos) == WireSide::None
        }
        fn wire_power(&self, _: &World, _: Pos) -> Option<u8> { None }
        fn wire_with_power(&self, _: &World, _: Pos, _: u8) -> Option<StateId> { None }
        fn wire_shape(&self, _: &World, _: Pos) -> Option<(u8, [WireSide; 4])> { None }
        fn wire_with_shape(&self, _: u8, _: [WireSide; 4]) -> Option<StateId> { None }
        fn should_connect_to(&self, _: &World, pos: Pos, from: Option<Dir>) -> bool {
            (pos.y == 1 && from.is_none() && self.at(pos) == WireSide::Up)
                || (pos.y == 0 && from.is_some() && self.at(pos) == WireSide::Side)
        }
        fn sturdy_up(&self, _: &World, pos: Pos) -> bool {
            pos.y == 0 && self.at(pos) == WireSide::Up
        }
        fn full_block(&self, _: &World, pos: Pos) -> bool {
            pos.y == 0 && self.at(pos) == WireSide::Up
        }
    }

    fn sides(mut value: usize) -> [WireSide; 4] {
        std::array::from_fn(|_| {
            let side = [WireSide::None, WireSide::Side, WireSide::Up][value % 3];
            value /= 3;
            side
        })
    }

    #[test]
    fn directional_answer_matches_all_raw_and_stored_shapes() {
        let pos = Pos::new(0, 0, 0);
        let world = World::new(Bounds::new(Pos::new(-2, -2, -2), Pos::new(2, 2, 2)));
        for raw in 0..81 {
            let rules = RawSides(sides(raw));
            for stored in 0..81 {
                let current = sides(stored);
                let expected = connection_state(&rules, &world, pos, current);
                for (index, toward) in WIRE_SIDES.into_iter().enumerate() {
                    let actual = connected_toward_by(current, toward, |dir| {
                        connecting_side(&rules, &world, pos, dir, true)
                    });
                    assert_eq!(actual, expected[index].connected(),
                        "raw={raw} stored={stored} toward={toward:?}");
                }
            }
        }
    }

    #[test]
    fn already_connected_direction_does_not_query_other_sides() {
        let mut calls = Vec::new();
        assert!(connected_toward_by([WireSide::None; 4], Dir::North, |dir| {
            calls.push(dir);
            WireSide::Up
        }));
        assert_eq!(calls, [Dir::North]);
    }
}

#[cfg(test)]
mod hash_order_ground_truth {
    use super::*;
    use crate::pos::Pos;

    /// Printed by real Java against the 26.2 jar:
    /// `HashSet<BlockPos>` seeded with a position and its six neighbours,
    /// iterated. This is the set `updatePowerStrength` walks to decide which
    /// positions hear a wire's power change, and its order is observable.
    #[test]
    fn the_hash_order_matches_real_java() {
        let cases: &[(Pos, &[(i32, i32, i32)])] = &[
            (
                Pos::new(2, 2, 3),
                &[
                    (2, 3, 3),
                    (2, 2, 2),
                    (1, 2, 3),
                    (2, 2, 3),
                    (2, 1, 3),
                    (2, 2, 4),
                    (3, 2, 3),
                ],
            ),
            (
                Pos::new(1, 10, 4),
                &[
                    (1, 11, 4),
                    (1, 10, 3),
                    (0, 10, 4),
                    (1, 10, 4),
                    (1, 9, 4),
                    (1, 10, 5),
                    (2, 10, 4),
                ],
            ),
            (
                Pos::new(2, 2, 2),
                &[
                    (2, 3, 2),
                    (2, 2, 1),
                    (1, 2, 2),
                    (2, 2, 2),
                    (2, 1, 2),
                    (2, 2, 3),
                    (3, 2, 2),
                ],
            ),
            (
                Pos::new(3, 2, 2),
                &[
                    (3, 3, 2),
                    (3, 2, 1),
                    (2, 2, 2),
                    (3, 2, 2),
                    (3, 1, 2),
                    (3, 2, 3),
                    (4, 2, 2),
                ],
            ),
            (
                Pos::new(4, 7, 2),
                &[
                    (4, 6, 2),
                    (4, 7, 3),
                    (5, 7, 2),
                    (4, 8, 2),
                    (4, 7, 1),
                    (3, 7, 2),
                    (4, 7, 2),
                ],
            ),
            (
                Pos::new(11, 7, 4),
                &[
                    (11, 8, 4),
                    (11, 7, 3),
                    (10, 7, 4),
                    (11, 7, 4),
                    (11, 6, 4),
                    (11, 7, 5),
                    (12, 7, 4),
                ],
            ),
            (
                Pos::new(2, 5, 3),
                &[
                    (2, 5, 3),
                    (2, 4, 3),
                    (2, 5, 4),
                    (3, 5, 3),
                    (2, 6, 3),
                    (2, 5, 2),
                    (1, 5, 3),
                ],
            ),
            (
                Pos::new(13, 5, 3),
                &[
                    (13, 6, 3),
                    (13, 5, 2),
                    (12, 5, 3),
                    (13, 5, 3),
                    (13, 4, 3),
                    (13, 5, 4),
                    (14, 5, 3),
                ],
            ),
            (
                Pos::new(0, 0, 0),
                &[
                    (0, 0, 0),
                    (0, 0, -1),
                    (-1, 0, 0),
                    (0, 0, 1),
                    (1, 0, 0),
                    (0, -1, 0),
                    (0, 1, 0),
                ],
            ),
            (
                Pos::new(7, 5, 1),
                &[
                    (7, 6, 1),
                    (7, 5, 0),
                    (6, 5, 1),
                    (7, 5, 1),
                    (7, 4, 1),
                    (7, 5, 2),
                    (8, 5, 1),
                ],
            ),
        ];
        for (pos, want) in cases {
            let got: Vec<(i32, i32, i32)> = java_hash_order(*pos, Pos::new(0, 0, 0))
                .iter()
                .map(|p| (p.x, p.y, p.z))
                .collect();
            let want: Vec<(i32, i32, i32)> = want.to_vec();
            assert_eq!(got, want, "hash order for {pos:?}");
        }
    }
}

#[cfg(test)]
mod hash_origin_matters {
    use super::*;
    use crate::pos::Pos;

    /// The same block, hashed where it stands and hashed at the origin, hands
    /// `updateNeighborsAt` its seven positions in different orders.
    ///
    /// Both sides are real Java run against the 26.2 jar. The dust cascade's
    /// cell at local (5,2,1) sits at world y=102 in the capture, and that one
    /// difference is the whole reason its six pistons fire 5,3,2,1,4,6 rather
    /// than sweeping 5,4,3,2,1,6 — and, a hundred blocks away in a saved world,
    /// the reason the vault door's tick-80 piston race went the other way.
    #[test]
    fn the_world_origin_changes_the_hash_order() {
        let cell = Pos::new(5, 2, 1);
        let at_origin: Vec<(i32, i32, i32)> = java_hash_order(cell, Pos::new(0, 0, 0))
            .iter()
            .map(|p| (p.x, p.y, p.z))
            .collect();
        let in_world: Vec<(i32, i32, i32)> = java_hash_order(cell, Pos::new(0, 100, 0))
            .iter()
            .map(|p| (p.x, p.y, p.z))
            .collect();

        assert_eq!(
            at_origin,
            vec![
                (5, 3, 1),
                (5, 2, 0),
                (4, 2, 1),
                (5, 2, 1),
                (5, 1, 1),
                (5, 2, 2),
                (6, 2, 1)
            ],
        );
        assert_eq!(
            in_world,
            vec![
                (5, 2, 1),
                (5, 1, 1),
                (5, 2, 2),
                (6, 2, 1),
                (5, 3, 1),
                (5, 2, 0),
                (4, 2, 1)
            ],
        );
        assert_ne!(at_origin, in_world, "the offset must not be a no-op");
    }
}

#[cfg(test)]
mod ordering_tests {
    use super::*;
fn bucket_reference(pos: Pos, origin: Pos) -> Vec<Pos> {
    let mut entries: Vec<Pos> = vec![pos];
    for dir in crate::pos::JAVA_DIRECTIONS {
        entries.push(pos.offset(dir));
    }
    let mut buckets: Vec<Vec<Pos>> = vec![Vec::new(); 16];
    for p in entries {
        // `BlockPos.hashCode` runs on the position the game holds, which is a
        // *world* position. This engine's world is zero-based, so the two agree
        // only when the build happens to sit at the origin. They differ by a
        // constant offset, and a constant offset does not preserve the bucket:
        // a dust cell at local y=2 and world y=102 hands `updateNeighborsAt`
        // its seven positions in genuinely different orders.
        let (x, y, z) = (
            p.x.wrapping_add(origin.x),
            p.y.wrapping_add(origin.y),
            p.z.wrapping_add(origin.z),
        );
        let hash = y
            .wrapping_add(z.wrapping_mul(31))
            .wrapping_mul(31)
            .wrapping_add(x);
        let spread = hash ^ (((hash as u32) >> 16) as i32);
        buckets[(spread & 15) as usize].push(p);
    }
    buckets.into_iter().flatten().collect()
}

    #[test]
    fn array_matches_java_bucket_reference() {
        let origins = [Pos::new(0,0,0), Pos::new(0,100,0), Pos::new(-31,-19,63),
            Pos::new(i32::MAX,i32::MIN,i32::MAX), Pos::new(i32::MIN,i32::MAX,i32::MIN)];
        for x in -10..10 { for y in -3..4 { for z in -2..3 {
            let p = Pos::new(x,y,z);
            for origin in origins { assert_eq!(java_hash_order_array(p, origin).as_slice(), bucket_reference(p,origin)); }
        } } }
    }
}
